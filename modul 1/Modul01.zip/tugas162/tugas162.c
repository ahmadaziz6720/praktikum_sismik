/*******************************************************
This program was created by the CodeWizardAVR V3.48a
Automatic Program Generator
� Copyright 1998-2022 Pavel Haiduc, HP InfoTech S.R.L.
http://www.hpinfotech.ro
Project : Tugas 1.6.2
Version : TP
Date : 09/02/2023
Author : Amelia Ats Tsaniyah F./13220002
Chip type : ATmega328P
Program type : Application
AVR Core Clock frequency: 16.000000 MHz
Memory model : Small
External RAM size : 0
Data Stack size : 512
*******************************************************/
#define button 2
int pin_on = 0;
int pin_off = 0;
int count = 0;
int pv_button = HIGH; //previous state of button
void setup() {
Laporan Praktikum - Laboratorium Dasar Teknik Elektro � STEI ITB 2
0
//assignment secara PIN untuk output LED, memakai pin 2-9
	pinMode(3, OUTPUT);
	pinMode(4, OUTPUT);
	pinMode(5, OUTPUT);
	pinMode(6, OUTPUT);
	pinMode(7, OUTPUT);
	pinMode(8, OUTPUT);
	pinMode(9, OUTPUT);
	pinMode(10, OUTPUT);
	pinMode(button,INPUT);
}
int i=0; //kondisi awal, karena pin dari 2 supaya lebih mudah saja
pembacaannya
void loop() {
	// Kondisi awal LED
	for (i==0;i<11;i++){
		digitalWrite(i+2,LOW);
	}

 //Menyalakan LED, state pertama dan inkremen
	pin_on = (count % 8) + 2; //pin yang transmit ON, mod untuk menghindari dari overflow
	pin_off = (count % 8)+1; //pin yang transmit ON, mod untuk menghindaridari overflow
	digitalWrite(pin_on, HIGH);
	digitalWrite(pin_off, LOW);
	//State button supaya hold, tidak langsung berubah
	if (digitalRead(button) != pv_button){
		pv_button = digitalRead(button);}
	}
	delay(200); //supaya aman, tidak overlap
}